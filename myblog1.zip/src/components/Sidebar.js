import React from 'react'

export const Sidebar=()=> {
  return (
    <div className="sidebar border">
      sidebar...
    </div>
  )
}
