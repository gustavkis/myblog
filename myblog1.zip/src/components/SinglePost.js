import React from 'react'

export const SinglePost=()=> {
  return (
    <div>
      single post...
    </div>
  )
}
