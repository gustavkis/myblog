import React from 'react'
import {Post} from './Post'

export const Posts=()=> {
  return (
    <div className="posts mt-3">
      <Post />
      <Post />
      <Post />
      <Post />
      <Post />
    </div>
  )
}
