import React from 'react'

export const Write=()=> {
  return (
    <div>
      write ....
    </div>
  )
}
