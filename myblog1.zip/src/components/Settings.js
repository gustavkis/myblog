import React from 'react'

export const Settings=()=>{
  return (
    <div>
      setting...
    </div>
  )
}
